# 机器人学基础

## 1.位姿
位置(position) = 位置(point) + 姿态(pose)


## 2.坐标变换 R和t
R：旋转矩阵 rotation
t：平移矩阵 translation